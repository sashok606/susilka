#include "WebUI.h"
#include <WiFi.h>
#include "../Config.h"

void WebUI::_handleSettings() {
  String html = F(
"<!doctype html><html lang=\"uk\"><meta charset=\"utf-8\">"
"<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">"
"<title>Налаштування Wi-Fi та ціна</title>"
"<style>"
"body{font-family:system-ui,-apple-system,Segoe UI,Roboto,Arial;background:#0b1020;color:#e8eef9;margin:0;padding:24px}"
".wrap{max-width:820px;margin:0 auto}"
".card{background:#121a2b;border:1px solid #1e2742;border-radius:16px;padding:16px;margin:0 0 16px;box-shadow:0 10px 30px rgba(0,0,0,.35)}"
"label{display:block;margin-top:10px}"
"input{width:100%;background:#0e1627;border:1px solid #2a3458;color:#e8eef9;border-radius:12px;padding:10px}"
"button{margin-top:14px;padding:10px 14px;border:0;border-radius:12px;background:#3b82f6;color:#fff;cursor:pointer}"
"a.btn{display:inline-block;margin-top:12px;color:#e8eef9}"
"</style>"
"<div class=\"wrap\"><div class=\"card\">"
"  <h1>Параметри Wi-Fi та ціни</h1>"
"  <form id=\"f\">"
"    <label>Назва мережі (STA SSID) <input name=\"sta_ssid\" maxlength=\"31\" required value=\"");
  html += _escape(String(CFG::cfg.sta_ssid));
  html += F("\"></label>"
"    <label>Пароль (STA) <input name=\"sta_pass\" maxlength=\"63\" value=\"");
  html += _escape(String(CFG::cfg.sta_pass));
  html += F("\"></label>"
"    <label>Назва точки доступу (AP SSID)  <input name=\"ap_ssid\" maxlength=\"31\" required value=\"");
  html += _escape(String(CFG::cfg.ap_ssid));
  html += F("\"></label>"
"    <label>Пароль (AP) <input name=\"ap_pass\" maxlength=\"63\" value=\"");
  html += _escape(String(CFG::cfg.ap_pass));
  html += F("\"></label>"
"    <hr style='border-color:#1e2742;margin:16px 0'>"
"    <label>Ціна електроенергії, грн за 1 кВт·год <input type=\"number\" step=\"0.01\" name=\"price_kwh\" value=\"");
  html += String(CFG::cfg.price_kwh, 2);
  html += F("\"></label>"
"    <button type=\"submit\">Зберегти (та перезавантажити)</button>"
"  </form>"
"  <a class=\"btn\" href=\"/\">← Повернутися</a>"
"</div></div>"
"<script>"
"document.getElementById('f').addEventListener('submit', async (e)=>{"
"  e.preventDefault();"
"  const fd=new FormData(e.target); const data=new URLSearchParams();"
"  for(const [k,v] of fd) data.append(k,v);"
"  const r = await fetch('/api/apply',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:data});"
"  if(r.ok){ alert('Збережено. Перезавантаження...'); setTimeout(()=>location.href='/',2000); }"
"  else   { alert('Помилка збереження'); }"
"});"
"</script>"
);
  _srv.send(200, "text/html; charset=utf-8", html);
}

void WebUI::_handleApply() {
  if (!_srv.hasArg("sta_ssid") || !_srv.hasArg("ap_ssid")) {
    _srv.send(400, "application/json", "{\"ok\":false,\"err\":\"bad_form\"}");
    return;
  }
  strlcpy(CFG::cfg.sta_ssid, _srv.arg("sta_ssid").c_str(), sizeof(CFG::cfg.sta_ssid));
  strlcpy(CFG::cfg.sta_pass, _srv.arg("sta_pass").c_str(), sizeof(CFG::cfg.sta_pass));
  strlcpy(CFG::cfg.ap_ssid,  _srv.arg("ap_ssid").c_str(),  sizeof(CFG::cfg.ap_ssid));
  strlcpy(CFG::cfg.ap_pass,  _srv.arg("ap_pass").c_str(),  sizeof(CFG::cfg.ap_pass));

  if (_srv.hasArg("price_kwh")) {
    CFG::cfg.price_kwh = _srv.arg("price_kwh").toFloat();
  }

  const bool ok = CFG::save();
  _srv.send(ok?200:500, "application/json", ok?"{\"ok\":true}":"{\"ok\":false}");
  if (ok) { delay(300); ESP.restart(); }
}
